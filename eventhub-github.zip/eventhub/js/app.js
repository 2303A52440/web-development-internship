// app.js — EventHub Application Logic

let events = [...EVENTS];

/* ── Navigation ── */
function showSection(id) {
  document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  document.querySelectorAll(`.nav-link`).forEach(l => {
    if (l.getAttribute('onclick') && l.getAttribute('onclick').includes(id)) l.classList.add('active');
  });
  if (id === 'dashboard') renderDashboard();
  if (id === 'calendar')  renderCalendar();
  if (id === 'alerts')    renderAlerts();
}

function toggleMenu() {
  document.getElementById('mobileMenu').classList.toggle('open');
}

/* ── Event Cards ── */
function renderEventCard(ev) {
  const pct = Math.round((ev.registered / ev.capacity) * 100);
  const btnClass = ev.isFull ? 'full' : ev.isRegistered ? 'registered' : '';
  const btnLabel = ev.isFull ? 'Full' : ev.isRegistered ? 'Registered ✓' : 'Register';

  return `
    <div class="event-card" data-id="${ev.id}">
      <div class="event-thumb" style="background:${ev.color}">${ev.emoji}</div>
      <div class="event-body">
        <div class="event-title">${ev.title}</div>
        <div class="event-meta">
          ${ev.date} · ${ev.time}<br>
          ${ev.location}<br>
          ${ev.organizer}
        </div>
        <div class="capacity-bar"><div class="capacity-fill" style="width:${pct}%"></div></div>
      </div>
      <div class="event-footer">
        <span class="tag tag-${ev.category}">${ev.category}</span>
        <span class="rating"><span>★</span> ${ev.rating}</span>
      </div>
      <div style="padding:0.6rem 1rem 0.75rem; display:flex; align-items:center; justify-content:space-between;">
        <span class="capacity-text">${ev.registered}/${ev.capacity} registered</span>
        <button class="btn-register ${btnClass}" onclick="toggleRegister(${ev.id})" ${ev.isFull && !ev.isRegistered ? 'disabled' : ''}>${btnLabel}</button>
      </div>
    </div>`;
}

function renderEvents(list) {
  const grid = document.getElementById('eventsGrid');
  if (!grid) return;
  grid.innerHTML = list.length
    ? list.map(renderEventCard).join('')
    : '<p style="color:var(--muted);grid-column:1/-1">No events match your filters.</p>';
}

/* ── Filter & Search ── */
function filterEvents() {
  const query = (document.getElementById('searchInput')?.value || '').toLowerCase();
  const checkedCats = [...document.querySelectorAll('.filters input[type="checkbox"]')]
    .filter(cb => cb.checked).map(cb => cb.nextSibling.textContent.trim());
  const dateFilter = document.querySelector('.filters input[type="radio"]:checked')?.value || 'all';
  const today = new Date();

  const filtered = events.filter(ev => {
    const matchCat = checkedCats.includes(ev.category);
    const matchSearch = ev.title.toLowerCase().includes(query) ||
      ev.organizer.toLowerCase().includes(query) ||
      ev.category.toLowerCase().includes(query);
    const evDate = new Date(ev.date);
    let matchDate = true;
    if (dateFilter === 'week') {
      const weekEnd = new Date(today); weekEnd.setDate(today.getDate() + 7);
      matchDate = evDate >= today && evDate <= weekEnd;
    } else if (dateFilter === 'month') {
      matchDate = evDate.getMonth() === today.getMonth() && evDate.getFullYear() === today.getFullYear();
    }
    return matchCat && matchSearch && matchDate;
  });

  renderEvents(filtered);
}

/* ── Register Toggle ── */
function toggleRegister(id) {
  const ev = events.find(e => e.id === id);
  if (!ev || ev.isFull) return;
  ev.isRegistered = !ev.isRegistered;
  ev.registered += ev.isRegistered ? 1 : -1;
  filterEvents();
}

/* ── Dashboard ── */
function renderDashboard() {
  const registered = events.filter(e => e.isRegistered);
  const grid = document.getElementById('dashboardEvents');
  if (grid) grid.innerHTML = registered.map(renderEventCard).join('') || '<p style="color:var(--muted)">No registered events yet.</p>';
}

/* ── Calendar ── */
function renderCalendar() {
  const grid = document.getElementById('calendarGrid');
  if (!grid) return;
  const days = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  let html = days.map(d => `<div class="cal-header">${d}</div>`).join('');

  const year = 2026, month = 5; // June 2026
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  for (let i = 0; i < firstDay; i++) html += `<div class="cal-day"></div>`;

  for (let d = 1; d <= daysInMonth; d++) {
    const dateStr = `2026-06-${String(d).padStart(2,'0')}`;
    const dayEvents = events.filter(e => e.date === dateStr);
    const isToday = d === 15;
    html += `<div class="cal-day${isToday ? ' today' : ''}${dayEvents.length ? ' has-event' : ''}">
      <div class="day-num">${d}</div>
      ${dayEvents.map(e => `<div class="cal-event-dot">${e.emoji} ${e.title}</div>`).join('')}
    </div>`;
  }
  grid.innerHTML = html;
}

/* ── Alerts ── */
function renderAlerts() {
  const list = document.getElementById('alertsList');
  if (!list) return;
  list.innerHTML = ALERTS.map(a => `
    <div class="alert-item ${a.unread ? 'unread' : ''}">
      <div class="alert-icon">${a.icon}</div>
      <div class="alert-content">
        <div class="alert-title">${a.title}</div>
        <div class="alert-time">${a.time}</div>
      </div>
    </div>`).join('');
}

/* ── Modal ── */
function openModal() {
  document.getElementById('modalOverlay').classList.add('open');
}
function closeModal() {
  document.getElementById('modalOverlay').classList.remove('open');
}
function createEvent() {
  const title    = document.getElementById('newTitle').value.trim();
  const dateVal  = document.getElementById('newDate').value;
  const location = document.getElementById('newLocation').value.trim();
  const category = document.getElementById('newCategory').value;
  const capacity = parseInt(document.getElementById('newCapacity').value) || 50;

  if (!title || !dateVal || !location) { alert('Please fill in all required fields.'); return; }

  const dt = new Date(dateVal);
  const dateStr = dt.toISOString().split('T')[0];
  const timeStr = dt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  const categoryEmojis = { Technology:'💻', Education:'📚', Business:'💼', Sports:'⚽', Arts:'🎨', Networking:'🤝' };
  const categoryColors = { Technology:'#e0e7ff', Education:'#fef3c7', Business:'#fce7f3', Sports:'#dcfce7', Arts:'#fce7d8', Networking:'#ede9fe' };

  const newEv = {
    id: events.length + 1,
    title, date: dateStr, time: timeStr, location,
    organizer: 'You', category,
    emoji: categoryEmojis[category],
    color: categoryColors[category],
    rating: 5.0, registered: 0, capacity,
    isRegistered: false, isFull: false
  };
  events.push(newEv);
  closeModal();
  filterEvents();
  showSection('browse');
}

/* ── Init ── */
document.addEventListener('DOMContentLoaded', () => {
  renderEvents(events);
});
