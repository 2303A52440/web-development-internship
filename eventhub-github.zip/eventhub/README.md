# 🎉 EventHub — Community Event Management Platform

A full-featured community event management web app built with **HTML, CSS, and JavaScript**. EventHub lets users browse events, register, manage a personal dashboard, view a calendar, receive alerts, and create new events.

![Browse Page](screenshots/screenshot-browse.png)
![Events Listing](screenshots/screenshot-events.png)

---

## ✨ Features

- **Browse & Filter Events** — filter by category, date range, and search by keyword
- **Event Registration** — register/unregister for events with live capacity tracking
- **Dashboard** — view all your registered events in one place
- **Calendar View** — see events plotted on a monthly calendar (June 2026)
- **Notifications / Alerts** — read event reminders and updates
- **Profile Page** — view your profile, badges, and attendance stats
- **Create New Events** — add events via a modal form
- **Responsive Design** — works on mobile, tablet, and desktop

---

## 🗂 Project Structure

```
eventhub/
├── index.html              # Main entry point
├── css/
│   └── style.css           # All styles (responsive)
├── js/
│   ├── data.js             # Sample event & notification data
│   └── app.js              # Application logic
├── database/
│   └── schema.sql          # Database schema + sample data (SQLite/MySQL)
├── screenshots/
│   ├── screenshot-browse.png
│   └── screenshot-events.png
└── README.md
```

---

## 🚀 Setup Instructions (Run Locally)

### Prerequisites
- A modern web browser (Chrome, Firefox, Edge, Safari)
- No server or build step required — it's pure HTML/CSS/JS!

### Steps

1. **Clone the repository**
   ```bash
   git clone https://github.com/2303A52440/web-development-internship.git
   cd web-development-internship
   ```

2. **Open the app**
   - Double-click `index.html`, **or**
   - Open your browser and navigate to the file:
     ```
     File → Open File → index.html
     ```

3. **That's it!** The app runs entirely in the browser with no dependencies.

---

## 🗄️ Database

The `database/schema.sql` file contains:
- Table definitions for `users`, `events`, `registrations`, `ratings`, and `notifications`
- Sample seed data matching the UI demo

To set it up with SQLite:
```bash
sqlite3 eventhub.db < database/schema.sql
```

To set it up with MySQL:
```bash
mysql -u root -p eventhub_db < database/schema.sql
```

---

## 🛠 Tech Stack

| Layer      | Technology             |
|------------|------------------------|
| Markup     | HTML5                  |
| Styling    | CSS3 (Custom Properties, Grid, Flexbox) |
| Logic      | Vanilla JavaScript (ES6+) |
| Database   | SQL (SQLite / MySQL compatible) |
| Hosting    | GitHub Pages / any static host |

---

## 📱 Responsive Breakpoints

| Breakpoint | Layout |
|------------|--------|
| ≥ 769px    | Two-column browse layout, full navbar |
| ≤ 768px    | Single-column, hamburger menu |
| ≤ 480px    | Compact cards, condensed calendar |

---

## 👨‍💻 Author

**Seetharam**  
GitHub: [@2303A52440](https://github.com/2303A52440)  
Internship Project — Web Development

---

## 📄 License

This project is open source and available under the [MIT License](LICENSE).
