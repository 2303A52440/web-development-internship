-- =============================================
-- EventHub — Community Event Management Platform
-- Database Schema (SQLite / MySQL compatible)
-- =============================================

-- Users table
CREATE TABLE IF NOT EXISTS users (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT    NOT NULL,
  email       TEXT    NOT NULL UNIQUE,
  password    TEXT    NOT NULL,         -- hashed
  avatar_url  TEXT,
  bio         TEXT,
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Events table
CREATE TABLE IF NOT EXISTS events (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  title       TEXT    NOT NULL,
  description TEXT,
  date        DATE    NOT NULL,
  time        TEXT    NOT NULL,
  location    TEXT    NOT NULL,
  category    TEXT    NOT NULL CHECK(category IN ('Technology','Education','Business','Sports','Arts','Networking')),
  capacity    INTEGER NOT NULL DEFAULT 100,
  organizer_id INTEGER NOT NULL,
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (organizer_id) REFERENCES users(id)
);

-- Registrations table
CREATE TABLE IF NOT EXISTS registrations (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL,
  event_id   INTEGER NOT NULL,
  registered_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id, event_id),
  FOREIGN KEY (user_id)  REFERENCES users(id),
  FOREIGN KEY (event_id) REFERENCES events(id)
);

-- Ratings table
CREATE TABLE IF NOT EXISTS ratings (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL,
  event_id   INTEGER NOT NULL,
  score      REAL    NOT NULL CHECK(score >= 1.0 AND score <= 5.0),
  review     TEXT,
  rated_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id, event_id),
  FOREIGN KEY (user_id)  REFERENCES users(id),
  FOREIGN KEY (event_id) REFERENCES events(id)
);

-- Notifications table
CREATE TABLE IF NOT EXISTS notifications (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL,
  message    TEXT    NOT NULL,
  is_read    BOOLEAN DEFAULT FALSE,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ── Sample Data ──────────────────────────────────────

INSERT OR IGNORE INTO users (name, email, password) VALUES
  ('Seetharam',    'seetharam@example.com',  'hashed_pw_1'),
  ('Ravi Kumar',   'ravi@example.com',       'hashed_pw_2'),
  ('Priya Reddy',  'priya@example.com',      'hashed_pw_3'),
  ('Anil Mehta',   'anil@example.com',       'hashed_pw_4'),
  ('Dr. Kavya Singh', 'kavya@example.com',   'hashed_pw_5');

INSERT OR IGNORE INTO events (title, description, date, time, location, category, capacity, organizer_id) VALUES
  ('Web Dev Workshop',         'Hands-on HTML/CSS/JS workshop for beginners.',       '2026-06-20','10:00 AM','Tech Hub, Hyderabad',           'Technology', 60,  2),
  ('Startup Pitch Night',      'Present your startup idea to investors.',            '2026-06-22','6:00 PM', 'Startup Hub, Banjara Hills',    'Business',   80,  3),
  ('Digital Photography Basics','Learn composition and lighting techniques.',        '2026-06-25','9:00 AM', 'Charminar Cultural Center',     'Arts',       30,  4),
  ('Python for Data Science',  'Introduction to Python, pandas, and matplotlib.',   '2026-06-28','11:00 AM','Online',                        'Technology', 100, 5),
  ('Community 5K Run',         'Fun run around Hussain Sagar lake.',                 '2026-07-02','6:30 AM', 'Hussain Sagar Lake Trail',      'Sports',     300, 1),
  ('Business Networking Mixer','Connect with professionals over drinks.',            '2026-07-05','7:00 PM', 'The Park Hotel, Somajiguda',    'Networking', 50,  2),
  ('Machine Learning Bootcamp','Two-day intensive ML fundamentals bootcamp.',        '2026-07-08','9:00 AM', 'IIIT Hyderabad',                'Education',  40,  5),
  ('Women in Tech Panel',      'Panel discussion with leading women in tech.',       '2026-07-10','3:00 PM', 'T-Hub, Raidurgam',             'Technology', 120, 3);

INSERT OR IGNORE INTO registrations (user_id, event_id) VALUES
  (1, 1), (1, 4), (1, 5);

INSERT OR IGNORE INTO ratings (user_id, event_id, score, review) VALUES
  (1, 1, 4.8, 'Great hands-on session!'),
  (1, 4, 4.7, 'Clear explanations, good pace.');

INSERT OR IGNORE INTO notifications (user_id, message) VALUES
  (1, 'Web Dev Workshop starts in 5 days — don''t forget!'),
  (1, 'Registration confirmed for Python for Data Science.'),
  (1, 'Machine Learning Bootcamp is now full.'),
  (1, 'Rate your experience at the AI Summit.'),
  (1, 'New event added: Women in Tech Panel — Jul 10.');
